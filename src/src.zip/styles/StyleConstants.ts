export enum StyleConstants {
  NAV_BAR_HEIGHT = '4rem',
}
